# Version number and release date.
VERSION_NUMBER=0.14.3
RELEASE_DATE=2005-03-14      # in "date +%Y-%m-%d" format
