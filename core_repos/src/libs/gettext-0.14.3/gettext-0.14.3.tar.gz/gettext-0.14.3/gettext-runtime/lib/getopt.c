#include "../../gettext-tools/lib/getopt.c"
