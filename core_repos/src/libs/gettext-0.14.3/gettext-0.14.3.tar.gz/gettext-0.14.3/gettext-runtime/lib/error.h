#include "../../gettext-tools/lib/error.h"
